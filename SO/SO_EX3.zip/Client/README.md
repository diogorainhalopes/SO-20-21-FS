# SO Project 2020-21
## Exercise 3 base code.

## How to run
Execute the following command:
```
./tecnicofs-client <inputfile> <server_socket_name>
```
